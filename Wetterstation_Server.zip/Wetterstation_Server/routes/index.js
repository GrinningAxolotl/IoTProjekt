var express     = require('express');
var mysql       = require('mysql');
var app         = express();
var bodyParser  = require('body-parser');
var router    = express.Router();


var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'user',
    password : 'password',
    database : 'weather_station',
    debug    :  false,
    connectionLimit : 100
});

app.use(express.static(__dirname + '/views'));
app.use('/scripts', express.static(__dirname + '/node_modules/vis/dist/'));

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

/* GET home page. */
router.get('/', function(req, res, next) {
    // get data from database
    connection.query('SELECT datum x, humidity y, sender_id, \'1\' `group` FROM dht22 ' +
        'UNION SELECT datum x, temp y, sender_id, \'2\' `group` FROM dht22', function (error, results, fields) {
        if (error) throw error;
        results = JSON.stringify(results);

        res.render('index', { data: results, title: 'MY WEATHER AND AIR QUALITY', secondTitle: 'Mainpage'});
    });
});

/*DHT22 Ref*/
router.get('/dht', function(req, res, next) {
    connection.query('SELECT datum x, humidity y, sender_id, 1 `group` FROM dht22 ' +
        'UNION SELECT datum x, temp y, sender_id, 2 `group` FROM dht22', function (error, results, fields) {
        if (error) throw error;
        results = JSON.stringify(results);

        res.render('index', { data: results, title: 'MY WEATHER AND AIR QUALITY', secondTitle: 'Temperature and humidity', data1name: 'Humidity (%)', data2name: 'Temperature (°C)', minLeft: '0', maxLeft: '30', minRight: '50', maxRight: '80'    });
    });
});

/*BMP280 Ref*/
router.get('/bmp', function(req, res, next) {
    connection.query('SELECT datum x,  pressure  y, sender_id, \'1\' `group` FROM bmp280 ' +
        'UNION SELECT datum x, temp y, sender_id, \'2\' `group` FROM bmp280', function (error, results, fields) {
        if (error) throw error;
        results = JSON.stringify(results);

        res.render('index', { data: results, title: 'MY WEATHER AND AIR QUALITY', secondTitle: 'Temperature and pressure', data1name: 'Pressure (hPa)', data2name: 'Temperature (°C)', minLeft: '0', maxLeft: '30', minRight: '1000', maxRight: '1020'    });
    });
});

/*CCS811 Ref*/
router.get('/ccs', function(req, res, next) {
    connection.query('SELECT datum x, CO2 y, sender_id, \'2\' `group` FROM ccs811 ' +
        'UNION SELECT datum x, TVOC y, sender_id, \'1\' `group` FROM ccs811', function (error, results, fields) {
        if (error) throw error;
        results = JSON.stringify(results);

        res.render('index', { data: results, title: 'MY WEATHER AND AIR QUALITY', secondTitle: 'CO2 and Total Volatile Organic Compound', data1name: 'TVOC (ppb)', data2name: 'CO2 (ppm)', minLeft: '300', maxLeft: '700', minRight: '-10', maxRight: '35'    });
    });
});

/*SCS011 Ref*/
router.get('/sds', function(req, res, next) {
    connection.query('SELECT datum x, PM10 y, sender_id, \'1\' `group` FROM sds011 ' +
        'UNION SELECT datum x, PM25 y, sender_id, \'2\' `group` FROM sds011', function (error, results, fields) {
        if (error) throw error;
        results = JSON.stringify(results);

        res.render('index', { data: results, title: 'MY WEATHER AND AIR QUALITY', secondTitle: 'Finedust', data1name: 'PM10 (µg/m³)', data2name: 'PM2.5 (µg/m³)', minLeft: '-10', maxLeft: '20', minRight: '-10', maxRight: '20'     });
    });
});

module.exports = router;
